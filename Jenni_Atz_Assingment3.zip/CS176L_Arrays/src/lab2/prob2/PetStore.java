/**
 * PetStore.java: Represents a pet store. Currently contains only Cats.
 *@author j.atz
 */

package lab2.prob2;

import java.util.ArrayList;

public class PetStore<cats> {
	
	
	/**Instance variables:
	 * Declare an ArrayList of Cats called cats:
	 * 
	 * @param args
	 * 
	 */
	
	private ArrayList <cat> cats = new ArrayList();
	private final int MAXCATS = 10;
	 // Methods:

    /**
     * Add a Cat object to the cats ArrayList.
     * Make sure that no more than MAXCATS Cats are in the PetStore.
     * @param Cat object to add to cats
     */

	
	public void addCat(cat cat) {
		//only add this cat if the # of cats would not exceed maxcats
		/**
		 * @jenni
		 */
		cats.add(cat); 
		
	}
	
	/**
     * List all Cats in the cats ArrayList.
     * Number the Cats starting from 0. List all of a Cat's data.
     */

	
	public void listCats() {
		
		// TODO: number the cats starting from 0
		/**
		 * @jenni
		 */
		for ( cat cat: cats) {
			
			System.out.println(cat.toString());
			
			//shorter: System.out.print
			
			
		}
		
	
	}	
	 /**
	     * Remove a Cat from the cats ArrayList by numeric index.
	     * @param int index of Cat to remove
	     */
	 public void removeCat (cat cat)
	    {
	    	
	    	cats.remove(cat);
	    	
	    }
	 
	 /**
	     * Remove all Cats from the cats ArrayList.
	     */

	    
	 public void clearCats() {
			
			cats.clear();
		}
		

		
	 /**
	     * Test the PetStore class methods in main() method below:
	     */


	public static void main(String[] args) {
		// TODO Auto-generated method stub

        // Construct a PetStore object mystore.


		// Construct and add a number of Cat objects to mystore.
		PetStore myStore = new PetStore ();
		
		
		cat morris = new cat(" Morris", 10, "Mix");
		

		myStore.addCat(morris);
		
		cat skitty = new cat(" Skitty", 16, "Mix");
		
		myStore.addCat(skitty);
		
	
	
		cat meiu = new cat(" Mieu", 5, "Manx");
		myStore.addCat(meiu);
		
		
		//list the cats in myStore
		myStore.listCats();
		
		// Try removing a previously-added Cat from mystore, and then list the Cats again.


			myStore.removeCat(meiu);
			myStore.listCats();
		
		
		
		

        

        
        // Clear all the Cats from mystore.

		myStore.clearCats();
		
		
        // List the Cats in mystore.


		myStore.listCats();

		
		

        // Add a total of 10 Cats to mystore.
		
		//0
		cat teddy = new cat(" Teddy", 7, "Bengal");
		myStore.addCat(teddy);
		
		
		//1
		cat midnight = new cat(" Midnight ", 5, "Bengal");
		myStore.addCat(midnight);
		
		//2
		cat sun = new cat (" Sun ", 10, "Persian");
		myStore.addCat(sun);
		
		
		//3
		cat theodore = new cat("Theodore", 2, "Scottish");
		myStore.addCat(theodore);
		
		//4 
		cat fifi = new cat("Fifi", 5 , "Scottish");
		myStore.addCat(fifi);
		
		//5
		cat moon = new cat ("Moon", 3, "Manx");
		myStore.addCat(moon);

		//6
		cat lily = new cat ("Lily", 4, "Mix");
		myStore.addCat(lily);
		
		
		//7
		cat charlie = new cat("Charlie", 11, "Mix");
		myStore.addCat(charlie);
		
		
		//8
		 cat milo = new cat ("Milo", 12, "Bengal");
		 myStore.addCat(milo);
		 
		 
		 //9
		 cat lucy = new cat ("Lucy", 15, "Manx");
		 
		 //10
		 myStore.addCat(new cat ("Dixie", 8, "Bengal"));
		 
		 
		
		
        // Try to add a 11th Cat to mystore, and note what happens.
		 
		 //11
		 myStore.addCat(new cat ("Phil", 5, "Manx"));
		 

		 
		 
        // List the Cats in mystore.
		 myStore.listCats();
		 
		 
		 // Clear all the Cats from mystore.
		
		 myStore.clearCats();
        		 
		

        // List the Cats in mystore.
		 
		 myStore.listCats();

     
		

	}	// end main()	
	

}// end PetStore 

