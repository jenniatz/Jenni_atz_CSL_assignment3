/**
 * cat.java: A cat class
 * @author: j.atz
 */
package lab2.prob2;

public class cat {

	
	//add instance varibale for name, age, breed:
	private String name;
	private int age;
	private String breed;
	
	//add a constructor that sets the cat name, age, and breed
	/**
	 * constructor #1
	 * @param name
	 * @param age
	 * @param breed
	 */
	
	public cat(String name, int age, String breed) {
		
		this.name = name;
		this.age = age;
		this.breed = breed;
		
	}
	
	
	//can also right, source, generate getters and setters
	//add method @return name
	/** 
	 * add 3 methods to return name, age, breed:
	 * @return
	 */
	public String getName () {
		return name;
	}
	
	
	public int getAge() {
		return age;
	}
	
	
	public String getBreed() {
		
		return breed;
	}
	
	
	

	//add toString method to return all cat data as one string
	//return a string representation of a cat;
	
	public String toString() {
		
		String all = "name: " + name + "\n" + 
					"age: " + age + "\n" + 
					"breed: " + breed
					+ "\n" + " ";
		
		return all;
	}
	
	
} //end cat 
